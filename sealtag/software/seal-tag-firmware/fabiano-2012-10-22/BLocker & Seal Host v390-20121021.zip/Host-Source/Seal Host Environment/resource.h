//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Seal Host Environment.rc
//
#define IDP_OLE_INIT_FAILED             100
#define IDD_SEALHOSTENVIRONMENT_DIALOG  102
#define IDP_SOCKETS_INIT_FAILED         103
#define IDR_MAINFRAME                   128
#define IDB_BITMAP1                     134
#define IDB_BITMAP2                     135
#define IDC_BUTTON1                     1000
#define IDC_BUTTON2                     1001
#define IDC_BUTTON3                     1002
#define IDC_BUTTON4                     1003
#define IDC_EDIT1                       1004
#define IDC_COMBO1                      1007
#define IDC_COMBO2                      1008
#define IDC_COMBO3                      1009
#define IDC_COMBO4                      1010
#define IDC_COMBO5                      1011
#define IDC_COMBO6                      1012
#define IDC_COMBO7                      1013
#define IDC_COMBO8                      1014
#define IDC_COMBO9                      1016
#define IDC_COMBO10                     1017
#define IDC_BUTTON_START_TIMER          1018
#define IDC_COMBO11                     1019
#define IDC_COMBO12                     1020
#define IDC_BUTTON_STOP_TIMER           1021
#define IDC_BUTTON_READ_5               1022
#define IDC_BUTTON_READ_1               1023
#define IDC_BUTTON_FLUSH                1024
#define IDC_EDIT2                       1025
#define IDC_BUTTON_READ_HISTORY         1026
#define IDC_EDIT3                       1027
#define IDC_BUTTON8                     1028
#define IDC_BUTTON_HISTORY2             1028
#define IDC_BUTTON_READ_ALL_HISTORY     1029
#define IDC_BUTTON_RTC_CALIBRATE_START  1030
#define IDC_BUTTON_RTC_CALIBRATE_READ   1031
#define IDC_IMG_LOGO                    1036
#define IDC_LOGO_HUNTER                 1037
#define IDC_RUNTIME                     1038
#define IDC_BUTTON_SERIAL               1039

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        136
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1040
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

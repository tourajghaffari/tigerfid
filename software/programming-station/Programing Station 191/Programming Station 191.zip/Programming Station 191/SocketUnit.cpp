//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "SocketUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TSocketForm *SocketForm;
//---------------------------------------------------------------------------
__fastcall TSocketForm::TSocketForm(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "AboutUnitNoLogo.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TAboutFormNoLogo *AboutFormNoLogo;
//---------------------------------------------------------------------------
__fastcall TAboutFormNoLogo::TAboutFormNoLogo(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------


using System;
using System.Collections.Generic;
using System.Text;

namespace AWIComponentLib
{
    class ConstantsClass
    {
        public const int OPEN_RELAY_01 = 100;
        public const int OPEN_RELAY_02 = 101;
        public const int CLOSE_RELAY_01 = 102;
        public const int CLOSE_RELAY_02 = 103; 
    }
}

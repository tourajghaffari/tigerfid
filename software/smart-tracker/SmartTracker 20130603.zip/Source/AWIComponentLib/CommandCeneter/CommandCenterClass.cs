using System;

namespace ActiveWave.CommandCenter
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	public class CommandCenterClass
	{
		public CommandCenterClass() {}
		
	}
}
